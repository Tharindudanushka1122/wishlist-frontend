const express = require('express');
const router = express.Router();
const Wishlist = require('../models/Wishlist');

router.get('/', async (req, res) => {
    const items = await Wishlist.find();
    res.json(items);
});

router.post('/', async (req, res) => {
    const newItem = new Wishlist(req.body);
    const saved = await newItem.save();
    res.json(saved);
});

router.delete('/:id', async (req, res) => {
    await Wishlist.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
});

module.exports = router;